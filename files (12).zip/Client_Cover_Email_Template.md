# Client Cover Email Template — 90-Day Onboarding Forms

**Subject:** Welcome to Lari Creative Studio — your 90-day onboarding forms

---

Hi [Client First Name],

Welcome aboard, and thank you for choosing Lari Creative Studio. We're excited to build a 90-day social media strategy that genuinely reflects [Business Name] and the customers you want to reach.

To do that well, we need to learn about your business, brand, audience and goals. We've split the questions into short, focused forms so you can complete them at your own pace.

**Step 1 — Core Business & Brand (Part A)**
[Link to Part A] · about 30–45 minutes
Near the end, you'll find a **Services & Investment** section. You can select the packages and add-ons that suit you, with starting prices in Naira and a running estimate. Nothing is compulsory, and your final proposal confirms the figures.

**Step 2 — Business Line Deep Dives (Part B)**
Please complete the form(s) that apply to you:
- Card Making: [Link to B1] · about 15–20 minutes
- Custom Apparel: [Link to B2] · about 15–20 minutes
- Picture Framing: [Link to B3] · about 15–20 minutes

**Helpful to have on hand**
- Your logo and brand colours or fonts
- Screenshots of your recent social media analytics
- A few examples of posts you love (yours or others')
- Photos of your best-selling products

You can upload these to our shared folder here: [Shared Folder Link]

**A few notes**
- There are no right or wrong answers. The more detail you share, the better we can tailor your strategy.
- If a question doesn't apply, simply write "N/A".
- Please aim to complete everything by **[Date]** so we can stay on schedule.

Once we've received your responses, we'll review everything and contact you within [3] business days to schedule your kickoff call.

If you have any questions along the way, just reply to this email. We're happy to help.

Warm regards,

[Your Name]
[Title]
Lari Creative Studio
[Phone] · laricreativestudio@gmail.com
[Website]

---

## Customisation notes
- Delete any Part B lines that don't apply to the client.
- Send Part A first and Part B after, if you prefer a staged approach. Use the "Short version" below for the second send.

## Short version (for sending Part B after Part A is complete)

**Subject:** Next step — your business line deep dives

Hi [Client First Name],

Thank you for completing Part A. It gives us a strong foundation. The next step is a short form for each of your business lines:

- [Link to B1] — Card Making
- [Link to B2] — Custom Apparel
- [Link to B3] — Picture Framing

Each takes about 15–20 minutes, and you're welcome to tackle them one at a time. Once they're in, we'll schedule your kickoff call within [3–5] business days.

Warm regards,
[Your Name]
Lari Creative Studio
